
# Metaware

A brief description of what this project does and who it's for


## Run Locally

Install dependencies

```bash
  npm install
```

Start the server

```bash
  npm run dev
```

