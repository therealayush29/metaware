import React from "react";

export default function IconHideArrow() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="4.562" height="18.345" viewBox="0 0 4.562 18.345">
        <path id="Path_993" data-name="Path 993" d="M2.28,0,0,7.737,2.28,15.87" transform="translate(1.04 1.242)" fill="none" stroke="#ffffff" strokeLinecap="round" strokeWidth="2"/>
    </svg> 
  )
}