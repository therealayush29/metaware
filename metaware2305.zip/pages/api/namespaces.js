import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function handler (req, res) {
  try {
    if (req.method === 'GET') {
      const namespaces = await prisma.namespace.findMany({
        include: {
          subjectarea: {
            include: {
              entity: true
            }
          }
        }
      })
      res.status(200).json(namespaces)
    } else if (req.method === 'POST') {
      const { id, type, name, runtime, privilege, tags, custom_props, txn_id, trace } = req.body
      const newNamespace = await prisma.namespace.create({
        data: {
          id,
          type,
          name,
          runtime,
          privilege,
          tags,
          custom_props,
          txn_id,
          trace
        },
        include: {
          subjectarea: {
            include: {
              entity: true
            }
          }
        }
      })
      res.status(201).json(newNamespace)
    } else {
      res.setHeader('Allow', ['GET', 'POST'])
      res.status(405).end(`Method ${req.method} Not Allowed`)
    }
  } catch (error) {
    console.error('Error handling request:', error)
    res.status(500).json({ error: 'Internal Server Error' })
  } finally {
    await prisma.$disconnect()
  }
}
