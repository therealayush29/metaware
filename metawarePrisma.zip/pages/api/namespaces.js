import { getNamespace } from '../../utils/api'

export default async function handler (req, res) {
  try {
    if (req.method === 'GET') {
      const namespaces = await getNamespace()
      res.status(200).json(namespaces)
    } else {
      res.setHeader('Allow', ['GET'])
      res.status(405).end(`Method ${req.method} Not Allowed`)
    }
  } catch (error) {
    console.error('Error handling request:', error)
    res.status(500).json({ error: 'Internal Server Error' })
  }
}
