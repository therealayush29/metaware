import prisma from '../lib/prisma'

export async function refetch (url, options = {}) {
  try {
    const response = await fetch(url, options)
    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.message)
    }
    return await response.json()
  } catch (error) {
    console.error('API fetch error:', error)
    throw error
  }
}

export const getNamespace = async () => {
  const namespaces = await prisma.namespace.findMany({
    include: {
      subjectarea: {
        include: {
          entity: true
        }
      }
    }
  })

  return namespaces
}

export const getMetaSubjectAreaById = async (id) => {
  const metaSubjectArea = await prisma.subjectarea.findUnique({
    where: { id },
    include: {
      entity: true, // Assuming `entity` is the relation name in the Prisma schema
      namespace: {
        select: {
          name: true
        }
      }
    }
  })

  return metaSubjectArea
}

export const getMetaMeta = async (name, subjectarea, type, namespace) => {
  const metaEntries = await prisma.meta.findMany({
    where: {
      entity: {
        name,
        subjectarea: {
          name: subjectarea,
          namespace: {
            type,
            name: namespace
          }
        }
      }
    },
    select: {
      id: true,
      name: true,
      type: true,
      subtype: true,
      nullable: true,
      description: true,
      alias: true,
      default: true,
      is_unique: true,
      order: true
    }
  })

  return metaEntries
}
